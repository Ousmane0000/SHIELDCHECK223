Projet Shield Check - Base de code structuree.
Note: Pour compiler, importez ce dossier dans un environnement Android.