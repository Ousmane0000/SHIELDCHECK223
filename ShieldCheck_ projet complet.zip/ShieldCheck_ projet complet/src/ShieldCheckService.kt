package com.shieldcheck.app

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.ComponentName

class ShieldCheckService(val context: Context) {

    fun verrouillerEtLocaliser(dpm: DevicePolicyManager, adminName: ComponentName) {
        // Définir le message de blocage
        dpm.setDeviceOwnerLockScreenInfo(adminName, 
            "BLOQUÉ PAR SHIELD CHECK : Ce téléphone est enregistré et tracé. Toute tentative de déblocage est localisée.")
        
        // Verrouiller l'appareil
        dpm.lockNow()
    }
}
